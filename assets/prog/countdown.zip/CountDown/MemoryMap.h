///////////////////////////////////////////////////////////////////////
// MemoryMap.cpp
// 
// Definition of the ShareString class. 
// Original author: John Bell
// Modified by: Francesco Montorsi (fr_m@hotmail.com)
// Version: 0.7
//
///////////////////////////////////////////////////////////////////////



#ifndef _SHARE_STRING_
#define _SHARE_STRING_

//includes 
#include <string.h>
#include <windows.h>
#include <tchar.h>



// if USE_SECURITY_ATTRIBUTES is defined, ShareString will compiled
// with the CreateMyDACL() function (taken from MSDN) and will use
// it when creating the file with Create()
#define USE_SECURITY_ATTRIBUTES

#ifdef USE_SECURITY_ATTRIBUTES

// the CreateMyDACL() function (which is taken 'as is' from MSDN)
// works only on Win2K, WinXP, Win2003 Server...
#define _WIN32_WINNT			0x0501

BOOL CreateMyDACL(SECURITY_ATTRIBUTES * pSA);

#endif



// Class definition: use a ShareString as a buffer shared between
// two or more processes. To use it, the first process must create
// the a ShareString in server-mode.
// Then, the other processes, using the same mapname in Create(), must
// connect to the shared string in client-mode.
// After this, the processes can start to communicate in duplex mode:
// everything is written with the set methods is immediately available
// to all the other processes using the get methods.
class ShareString
{
public:

	// constructors
	ShareString(const char *mapname, bool srv, const char *filename, bool bHide);
	ShareString();

	// destructor
	~ShareString();
	
	
	// Creates a file-mapped object with the following access
	// (if USE_SECURITY_ATTRIBUTES is defined):
	// -   Built-in guests are denied all access.
	// -   Anonymous logon is denied all access.
	// -   Authenticated users are allowed read/write/execute access.
	// -   Administrators are allowed full control.
	//
	// Use this rather than the available constructor to get
	// a return value indicating success or failure...
	//
	// If you want to create the string in server-mode
	// (thus, using srv = TRUE), the given filename must not
	// be the name of an existing file. In this case, you
	// can also use TRUE for the last argument if you want
	// to mark the mapped file as hidden.
	// 
	// If you want to create the string in client-mode
	// (thus, using srv = FALSE), the filename is ignored.
	// VERY IMPORTANT: to connect with the server, you must 
	// use the same mapname the server used to create the string
	bool Create(const char *mapname, bool srv = FALSE, 
		const char *filename = NULL, bool bHide = FALSE);

	// Closes the shared filemap and deletes it.
	void Delete();

	// Writes the given string in the shared portion of memory:
	// it's immediately accessible by all the other processes
	// connected with this string. Communication through
	// ShareString is always in duplex-mode, so this function
	// works both in server- and client- mode.
	//
	// VERY IMPORTANT: the given string must not contain the
	//                 following char: ` (ASCII code = 96)
	void setString(const char *str);

	// Reads the first n-characters of the current shared string.
	// Caller must provide the 'str' array where the contents
	// of the shared string are copied (of course it must be,
	// at least, of n bytes).
	void getString(char *str, int n);

	long getNum();
	void setNum(long n);



	// special uses functions
	bool isFileMapped();
	bool MapFile(const char *name);


protected:

	void CopyData(void *source, void *dest, DWORD size);
	void left(char *s, int num);
	int findchar(const char *s, const char fnd);
	
private:

	HANDLE m_hFile;
	HANDLE m_hMap;

	DWORD *m_pMapStart;
	char m_szFileName[32];

};

#endif
