///////////////////////////////////////////////////////////////////////
// MyService.h
// 
// Definition of CMyService. 
//
///////////////////////////////////////////////////////////////////////


#ifndef MYSERVICE_H
#define MYSERVICE_H

// required includes
#include "Service.h"
#include "../MemoryMap.h"
#include "../Globals.h"
#include "CountDown.h"


// some defines
#define EXE_NAME				"CDS"
#define NAME					"CountDown Service"
#define PASSWORD				"3.14159"
#define START_TIME				40*60			// in secs



// A COUNTDOWN SERVICE
class CMyService : public CService
{
public:									// functions
	CMyService();

	// CMyService functions
	void PrintUsage();

	// ovverrides from CService
	virtual bool OnInit();
	virtual void OnStop();
    virtual void Run();
	virtual void HandleMsg(int);
	virtual bool ParseStandardArgs(int argc, char* argv[]);
    virtual bool OnUserControl(DWORD dwOpcode);
	virtual bool OnUserOption(int count, char **arg);
	virtual bool StopServiceFromDOS();

	const char *GetDescription() { 
		return "Performs a countdown which starts automatically at system boot-up."
		"The countdown is automatically set to 40 minutes. To stop it, extend it or "
		"just get some info, try to run the EXE associated with this service from an "
		"MS-DOS command line.";	
	}

	const char *GetDisplayName() { return NAME; }

public:

	// handles all about the count down
	CCountDown m_cCountDown;

	// handles the communication with other processes
	ShareString m_strShared;
};


#endif
