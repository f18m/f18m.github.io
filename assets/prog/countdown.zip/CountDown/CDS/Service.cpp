///////////////////////////////////////////////////////////////////////
// Service.cpp
// 
// Implementation of the CService class. This class is a modified
// (and much extended !!!!) version of the CNTService class 
// which I found on the MSDN.
// It doesn't uses event logging nor the message compiler.
// Removing those two features, I simplified it very much !!!
//
///////////////////////////////////////////////////////////////////////


// includes
#include <windows.h>
#include <stdio.h>
#include "Service.h"


// static variables
CService* CService::m_pThis = NULL;




CService::CService(const char* szServiceName, DWORD dwStartType, DWORD dwServiceType)
{
    // copy the address of the current object so we can access it from
    // the static member callback functions. 
    // WARNING: This limits the application to only one CService object. 
    m_pThis = this;

    strncpy(m_szServiceName, szServiceName, sizeof(m_szServiceName)-1);

	// these doesn't work: this is why I created the GetDisplayName()
	// and the GetDescription() functions !!!
    //strcpy(m_szDisplayName, szDisplayName);//, sizeof(m_szDisplayName)-1);
    //strcpy(m_szDescription, szDescription);//, sizeof(m_szDescription)-1);

    m_iMajorVersion = 1;
    m_iMinorVersion = 0;
	m_dwStartType = dwStartType;
	m_dwServiceType = dwServiceType;

    // set up the initial service status 
    m_hServiceStatus = NULL;
    m_Status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    m_Status.dwCurrentState = SERVICE_STOPPED;
    m_Status.dwControlsAccepted = SERVICE_ACCEPT_STOP;
    m_Status.dwWin32ExitCode = 0;
    m_Status.dwServiceSpecificExitCode = 0;
    m_Status.dwCheckPoint = 0;
    m_Status.dwWaitHint = 0;
    m_bIsRunning = FALSE;
}

CService::~CService()
{
    DebugMsg("CService::~CService()");
}




////////////////////////////////////////////////////////////////////////////////////////
// Default command line argument parsing

// Returns TRUE if it found an arg it recognised, FALSE if not
// Note: processing some arguments causes output to stdout to be generated.
bool CService::ParseStandardArgs(int argc, char* argv[])
{
    // See if we have any command line args we recognise
    if (argc <= 1) return FALSE;

    if (_stricmp(argv[1], "-version") == 0) {

        // Spit out version info
        printf("%s Version %d.%d\n",
               m_szServiceName, m_iMajorVersion, m_iMinorVersion);
        printf("The service is %s installed\n",
               IsInstalled() ? "currently" : "not");
        return TRUE; // say we processed the argument

    } else if (_stricmp(argv[1], "-install") == 0) {

        // Request to install.
        if (IsInstalled()) {
            printf("%s is already installed\n", m_szServiceName);
        } else {
            // Try and install the copy that's running
            if (Install()) {
                printf("%s installed\n", m_szServiceName);
            } else {
                printf("%s failed to install. Error %d\n",
					m_szServiceName, GetLastError());
            }
        }
        return TRUE; // say we processed the argument

    } else if (_stricmp(argv[1], "-unistall") == 0) {

        // Request to uninstall.
        if (!IsInstalled()) {
            printf("%s is not installed\n", m_szServiceName);
        } else {
            // Try and remove the copy that's installed
            if (Uninstall()) {
                // Get the executable file path
                char szFilePath[_MAX_PATH];
                ::GetModuleFileName(NULL, szFilePath, sizeof(szFilePath));
                printf("%s removed. (You must delete the file %s yourself.)\n",
                       m_szServiceName, szFilePath);
            } else {
                printf("Could not remove %s. Error %d\n", 
					m_szServiceName, GetLastError());
            }
        }
        return TRUE; // say we processed the argument
    
    } else {

		// a derived-class defined option ? 
		return OnUserOption(argc, argv);
	}
         
    // Don't recognise the args
    return FALSE;
}




////////////////////////////////////////////////////////////////////////////////////////
// Install/uninstall routines

// Test if the service is currently installed
bool CService::IsInstalled()
{
    bool bResult = FALSE;

    // Open the Service Control Manager
    SC_HANDLE hSCM = ::OpenSCManager(NULL, // local machine
                                     NULL, // ServicesActive database
                                     SC_MANAGER_ALL_ACCESS); // full access
    if (hSCM) {

        // Try to open the service
        SC_HANDLE hService = ::OpenService(hSCM,
                                           m_szServiceName,
                                           SERVICE_QUERY_CONFIG);
        if (hService) {
            bResult = TRUE;
            ::CloseServiceHandle(hService);
        }

        ::CloseServiceHandle(hSCM);
    }
    
    return bResult;
}

bool CService::IsRunning()
{
	return m_bIsRunning;
}

bool CService::Install()
{
    // Open the Service Control Manager
    SC_HANDLE hSCM = ::OpenSCManager(NULL, // local machine
                                     NULL, // ServicesActive database
                                     SC_MANAGER_ALL_ACCESS); // full access
    if (!hSCM) return FALSE;

    // Get the executable file path
    char szFilePath[_MAX_PATH];
    ::GetModuleFileName(NULL, szFilePath, sizeof(szFilePath));

    // Create the service
    SC_HANDLE hService = ::CreateService(hSCM,
                                         m_szServiceName,
                                         GetDisplayName(),
                                         SERVICE_ALL_ACCESS,
                                         m_dwServiceType,
                                         m_dwStartType,        // start condition
                                         SERVICE_ERROR_NORMAL,
                                         szFilePath,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL);
    if (!hService) {
        ::CloseServiceHandle(hSCM);
        return FALSE;
    }

	// add description
	SERVICE_DESCRIPTION sd;
	sd.lpDescription = new char[1024];
	const char *p = GetDescription();
	strcpy(sd.lpDescription, p);
	ChangeServiceConfig2(hService, SERVICE_CONFIG_DESCRIPTION, &sd);
	delete [] sd.lpDescription;

    // make registry entries to support logging messages
    // Add the source name as a subkey under the Application
    // key in the EventLog service portion of the registry.
    char szKey[256];
    HKEY hKey = NULL;
    strcpy(szKey, "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\");
    strcat(szKey, m_szServiceName);
    if (::RegCreateKey(HKEY_LOCAL_MACHINE, szKey, &hKey) != ERROR_SUCCESS) {
        ::CloseServiceHandle(hService);
        ::CloseServiceHandle(hSCM);
        return FALSE;
    }

    // Add the Event ID message-file name to the 'EventMessageFile' subkey.
    ::RegSetValueEx(hKey,
                    "EventMessageFile",
                    0,
                    REG_EXPAND_SZ, 
                    (CONST BYTE*)szFilePath,
                    strlen(szFilePath) + 1);     

    // Set the supported types flags.
    DWORD dwData = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | EVENTLOG_INFORMATION_TYPE;
    ::RegSetValueEx(hKey,
                    "TypesSupported",
                    0,
                    REG_DWORD,
                    (CONST BYTE*)&dwData,
                     sizeof(DWORD));
    ::RegCloseKey(hKey);

    DebugMsg("The %s service was installed.", m_szServiceName);

    // tidy up
    ::CloseServiceHandle(hService);
    ::CloseServiceHandle(hSCM);
    return TRUE;
}

bool CService::Uninstall()
{
    // Open the Service Control Manager
    SC_HANDLE hSCM = ::OpenSCManager(NULL, // local machine
                                     NULL, // ServicesActive database
                                     SC_MANAGER_ALL_ACCESS); // full access
    if (!hSCM) return FALSE;

    bool bResult = FALSE;
    SC_HANDLE hService = ::OpenService(hSCM,
                                       m_szServiceName,
                                       DELETE);
    if (hService) {
        if (::DeleteService(hService)) {
            DebugMsg("The %s service was removed.", m_szServiceName);
            bResult = TRUE;
        } else {
            DebugMsg("The %s service could not be removed.", m_szServiceName);
        }
        ::CloseServiceHandle(hService);
    }
    
    ::CloseServiceHandle(hSCM);
    return bResult;
}




//////////////////////////////////////////////////////////////////////////////////////////////
// Service startup and registration

bool CService::StartService()
{
    SERVICE_TABLE_ENTRY st[] = {
        {m_szServiceName, ServiceMain},
        {NULL, NULL}
    };

    DebugMsg("Calling StartServiceCtrlDispatcher()");
    bool b = (::StartServiceCtrlDispatcher(st) != 0);

	int tmp = GetLastError();
    DebugMsg("Returned from StartServiceCtrlDispatcher(): %d", tmp);
    return b;
}

// static member function (callback)
void CService::ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv)
{
    // Get a pointer to the C++ object	
    CService* pService = m_pThis;
    DebugMsg("Entering CService::ServiceMain()");
    
	// Register the control request handler
    pService->m_Status.dwCurrentState = SERVICE_START_PENDING;
    pService->m_hServiceStatus = RegisterServiceCtrlHandler(pService->m_szServiceName,
                                                           Handler);
    if (pService->m_hServiceStatus == NULL) {
        DebugMsg("The control handler could not be installed.");
        return;
    }

    // Start the initialisation
    if (pService->Initialize()) {

        // Do the real work. 
        // When the Run function returns, the service has stopped.
        pService->m_bIsRunning = TRUE;
        pService->m_Status.dwWin32ExitCode = 0;
        pService->m_Status.dwCheckPoint = 0;
        pService->m_Status.dwWaitHint = 0;
        pService->Run();
    }

    // Tell the service manager we are stopped
    pService->SetStatus(SERVICE_STOPPED);

    DebugMsg("Leaving CService::ServiceMain()");
}




///////////////////////////////////////////////////////////////////////////////////////////
// status functions

void CService::SetStatus(DWORD dwState)
{
    DebugMsg("CService::SetStatus(%lu, %lu)", m_hServiceStatus, dwState);
    m_Status.dwCurrentState = dwState;
    ::SetServiceStatus(m_hServiceStatus, &m_Status);
}





///////////////////////////////////////////////////////////////////////////////////////////
// Service initialization

bool CService::Initialize()
{
    DebugMsg("Entering CService::Initialize()");

    // Start the initialization
    SetStatus(SERVICE_START_PENDING);
    
    // Perform the actual initialization
    bool bResult = OnInit(); 
    
    // Set final state
    m_Status.dwWin32ExitCode = GetLastError();
    m_Status.dwCheckPoint = 0;
    m_Status.dwWaitHint = 0;
    if (!bResult) {
        DebugMsg("The initialization process failed.");
        SetStatus(SERVICE_STOPPED);
        return FALSE;    
    }
    
    DebugMsg("The service was started.");
    SetStatus(SERVICE_RUNNING);

    DebugMsg("Leaving CService::Initialize()");
    return TRUE;
}





///////////////////////////////////////////////////////////////////////////////////////////////
// main function to do the real work of the service

// This function performs the main work of the service. 
// When this function returns the service has stopped.
void CService::Run()
{
    DebugMsg("Entering CService::Run()");

    while (m_bIsRunning) {
        DebugMsg("Sleeping...");
        Sleep(5000);
    }

    // nothing more to do
    DebugMsg("Leaving CService::Run()");
}





//////////////////////////////////////////////////////////////////////////////////////
// Control request handlers

void CService::HandleMsg(int dwOpcode)
{
    DebugMsg("CService::Handler(%lu)", dwOpcode);
    switch (dwOpcode) {
    case SERVICE_CONTROL_STOP: // 1
        SetStatus(SERVICE_STOP_PENDING);
        OnStop();
        m_bIsRunning = FALSE;
        DebugMsg("The service was stopped.");
        break;

    case SERVICE_CONTROL_PAUSE: // 2
        OnPause();
        break;

    case SERVICE_CONTROL_CONTINUE: // 3
        OnContinue();
        break;

    case SERVICE_CONTROL_INTERROGATE: // 4
        OnInterrogate();
        break;

    case SERVICE_CONTROL_SHUTDOWN: // 5
        OnShutdown();
        break;

    default:
        if (dwOpcode >= 128) {
            if (!OnUserControl(dwOpcode)) {
                DebugMsg("The service received an unsupported request.");
            }
        } else {
            DebugMsg("The service received an unsupported request.");
        }
        break;
    }

    // Report current status
    DebugMsg("Updating status (%lu, %lu)",
                       m_hServiceStatus,
                       m_Status.dwCurrentState);
    ::SetServiceStatus(m_hServiceStatus, &m_Status);
}

// static member function (callback) to handle commands from the
// service control manager
void CService::Handler(DWORD dwOpcode)
{
    // Get a pointer to the object
    CService* pService = m_pThis;
    pService->HandleMsg(dwOpcode);
}
        
// Called when the service is first initialized
bool CService::OnInit()
{
    DebugMsg("CService::OnInit()");
	return TRUE;
}

// Called when the service control manager wants to stop the service
void CService::OnStop()
{
    DebugMsg("CService::OnStop()");
}

// called when the service is interrogated
void CService::OnInterrogate()
{
    DebugMsg("CService::OnInterrogate()");
}

// called when the service is paused
void CService::OnPause()
{
    DebugMsg("CService::OnPause()");
}

// called when the service is continued
void CService::OnContinue()
{
    DebugMsg("CService::OnContinue()");
}

// called when the service is shut down
void CService::OnShutdown()
{
    DebugMsg("CService::OnShutdown()");
}

// called when the service gets a user control message
bool CService::OnUserControl(DWORD dwOpcode)
{
    DebugMsg("CService::OnUserControl(%8.8lXH)", dwOpcode);
    return FALSE; // say not handled
}

bool CService::OnUserOption(int count, char **arg)
{
    DebugMsg("CService::OnUserOption()");
    return FALSE; // say not handled
}





////////////////////////////////////////////////////////////////////////////////////////////
// Service-access functions

bool CService::StartServiceFromDOS()
{
	// We must START the service. We sure cannot use the StartService()
	// function: this is not the system instance of the service; this
	// is an instance created by the user from the MS-DOS prompt...
	// we must use Win32 service-access functions...
	
    // open the service control manager
    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL) {
		DebugMsg("CService::StartServiceFromDOS() - Couldn't open the "
							"service manager (error %d)", GetLastError());
		return FALSE;
	}

    // open the service
    SC_HANDLE hService = OpenService(hSCM, m_szServiceName, SERVICE_START);
    if (hService == NULL) {
		DebugMsg("CService::StartServiceFromDOS() - Couldn't open the "
							"service (error %d)", GetLastError());
		return FALSE;
	}

    // start the service
    BOOL b = ::StartService(hService, 0, NULL);
    if(!b) {
		DebugMsg("CService::StartServiceFromDOS() - Couldn't start the "
							"service (error %d)", GetLastError());
		return FALSE;
    }

    // close the service handle
    CloseServiceHandle(hService);

    // close the service control manager handle
    CloseServiceHandle(hSCM);

	return TRUE;
}

bool CService::IsRunningFromDOS()
{
	BOOL b;

	// open the service control manager
	SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL) {
		DebugMsg("CService::IsRunningDOS() - Couldn't open the "
							"service manager (error %d)", GetLastError());
		return FALSE;
	}
	
	// open the service
	DWORD dwState;
	SC_HANDLE hService = OpenService(hSCM, m_szServiceName,
		SERVICE_QUERY_STATUS | SERVICE_INTERROGATE);
	if (hService) {
		
		// Get the current status
		SERVICE_STATUS ss;
		memset(&ss, 0, sizeof(ss));
		b = QueryServiceStatus(hService, &ss);
		
		dwState = ss.dwCurrentState;
		
		// close the service handle
		CloseServiceHandle(hService);
	}
	
	// close the service control manager handle
	CloseServiceHandle(hSCM);
	
	if (!b || hService == NULL) {
		
		// ooops, one of the last operations gone bad...
		DebugMsg("CService::IsRunningDOS() - Couldn't query or open the "
				"service (error %d)", GetLastError());
		return FALSE;
	}
	
	// is the service running ?
	if (dwState == SERVICE_RUNNING)
		return TRUE;

	return FALSE;
}

bool CService::StopServiceFromDOS()
{
    // open the service control manager
    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL) {
		DebugMsg("CService::StopServiceFromDOS() - Couldn't open the "
							"service manager (error %d)", GetLastError());
		return FALSE;
	}

    // open the service
    SC_HANDLE hService = OpenService(hSCM,
                                     m_szServiceName,
                                     SERVICE_STOP);
	if (hService == NULL) {
		DebugMsg("CService::StopServiceFromDOS() - Couldn't open the "
							"service (error %d)", GetLastError());
		return FALSE;
	}

    // stop the service
    SERVICE_STATUS ss;
    BOOL b = ControlService(hService,
                            SERVICE_CONTROL_STOP,
                            &ss);
	if (!b) {
		DebugMsg("CService::StopServiceFromDOS() - Couldn't stop the "
							"service (error %d)", GetLastError());
		return FALSE;
	}

    // close the service handle
    CloseServiceHandle(hService);

    // close the service control manager handle
    CloseServiceHandle(hSCM);

	return TRUE;
}

bool CService::SendUserCommandFromDOS(int cmd)
{
    // open the service control manager
    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL) {
		DebugMsg("CService::SendUserCommandFromDOS() - Couldn't open the "
							"service manager (error %d)", GetLastError());
		return FALSE;
	}

    // open the service
    SC_HANDLE hService = OpenService(hSCM,
                                     m_szServiceName,
                                     SERVICE_USER_DEFINED_CONTROL);
	if (hService == NULL) {
		DebugMsg("CService::SendUserCommandFromDOS() - Couldn't open the "
							"service (error %d)", GetLastError());
		return FALSE;
	}

    // stop the service
    SERVICE_STATUS ss;
    BOOL b = ControlService(hService,
                            cmd,		// the user-defined command
                            &ss);
	if (!b) {
		DebugMsg("CService::SendUserCommandFromDOS() - Couldn't send to the "
							"service a user-defined command (error %d)", GetLastError());
		return FALSE;
	}

    // close the service handle
    CloseServiceHandle(hService);

    // close the service control manager handle
    CloseServiceHandle(hSCM);

	return TRUE;
}



////////////////////////////////////////////////////////////////////////////////////////////
// Debugging support

void DebugMsg(const char* pszFormat, ...)
{
    char buf[1024];
    sprintf(buf, "[%s](%lu): ", __FILE__, GetCurrentThreadId());
	va_list arglist;
	va_start(arglist, pszFormat);
    vsprintf(&buf[strlen(buf)], pszFormat, arglist);
	va_end(arglist);
    strcat(buf, "\n");
    OutputDebugString(buf);
}


