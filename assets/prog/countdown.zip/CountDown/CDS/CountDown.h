///////////////////////////////////////////////////////////////////////
// CountDown.h
// 
// Definition of the CCountDown class.
//
///////////////////////////////////////////////////////////////////////


#ifndef COUNTDOWN_H
#define COUNTDOWN_H


// defines
#define NUM_WARNINGS				2


// includes 
#include <windows.h>


// a simple structure used to communicate
// with the asynchronous message box
typedef struct {
	char *pContent;
	char *pTitle;
} MSG_DATA;



// The COUNTDOWN class.
class CCountDown {

	// the end time set for the count down: it uses the GetTickCount()
	// function and then compares the returned value with this variable
	unsigned long m_nEndTime;

	// the turn off time set for the poweroff
	unsigned long m_nTurnOffTime;

	// the seconds between two poweroff tries
	int m_nInterTurnOffStepTime;

	// the seconds after each warning appears.
	int m_nWarning[NUM_WARNINGS];
	bool m_bWarning[NUM_WARNINGS];		// a bitmap which indicates the warning already appeared
	

	// returns the number of tick counts before the turnoff: this
	// value can be different from m_nEndTime because the
	// first turn off step begins BEFORE m_nEndTime == 0
	long GetTurnOffTime();
	
public:
	
	CCountDown() {
		
		m_nTurnOffTime = 0xFFFF;		// this will be set by SetCountLenght
		m_nInterTurnOffStepTime = 10;		// 10 seconds between two poweroff tries
		
		m_nWarning[0] = 5*60;		// set first warning at 5 minutes before poweroff
		m_nWarning[1] = 1*60;

		ResetWarnings();
	}
	
	// helper functions
	void TurnOffPC();
	static long SystemTime2Seconds(SYSTEMTIME &time);
	static bool SetPrivilege(HANDLE, LPCTSTR, BOOL bEnablePrivilege) ;
	
	// CCountDown main functions
	void ExtendEndTime(unsigned long);		// use seconds
	void SetCountLenght(unsigned long);		// use seconds
	long GetSecondsLeft();
	void Run();
	void ResetWarnings();
	
	// to use async message boxes
	static unsigned long WINAPI AsyncMsgProc(void *);
	static void ShowAsyncMsg(char *, char *);
};

#endif
