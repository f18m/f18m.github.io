///////////////////////////////////////////////////////////////////////
// MyService.cpp
// 
// Implementation of the CMyService class. It derives from CService
// and contains an instance of the CCountDown class. 
// CMyService has three tasks:
//
// 1) security: it allows command handling only if the correct password
//              is passed.
//
// 2) background execution: every 5 seconds, it calls the Run()
//                          function of the CCountDown class.
//
// 3) communication with other processes: through the ShareString class.
//
///////////////////////////////////////////////////////////////////////


// includes
#include "ServiceApp.h"
#include "MyService.h"



CMyService::CMyService() : 
		CService(SERVICE_NAME, SERVICE_AUTO_START)
{
	// I tried to register the service as a kernel driver or a
	// device driver (trying to make it invisible in the
	// task manager's list) but in that way I couldn't start it....
	// so I reverted to a normal SERVICE_WIN32_OWN_PROCESS... :-(
	m_iMinorVersion = 2;
}

bool CMyService::OnInit()
{
	DebugMsg("CMyService::OnInit() - setting up the countdown");

	// init start time to 40 minutes
	m_cCountDown.SetCountLenght(START_TIME);

	// create a shared string using as mapname 'CDS'
	// and as file an hidden file called 'cds' placed in
	// the main hard-disk...
	m_strShared.Create(IO_MAP, TRUE, "c:\\cds.txt", FALSE);

	return TRUE;
}

void CMyService::OnStop()
{
	DebugMsg("CMyService::OnStop() - deleting shared object");
	m_strShared.Delete();	
}

void CMyService::Run()
{
	DebugMsg("CMyService::Run() - Running count down service");

    while (IsRunning()) {
		
		// check if the time has expired
		m_cCountDown.Run();
        DebugMsg(NAME " is counting down: %d seconds left",
								m_cCountDown.GetSecondsLeft());

		// wait 5 seconds
		Sleep(5000);
    }

	DebugMsg("CMyService::Run() - Exiting CountDown Run() function");
}

void CMyService::HandleMsg(int dwOpcode)
{
	char tmp[64];

	if (dwOpcode == SERVICE_CONTROL_STOP) {

		// stop only if password is set in the correct file
		m_strShared.getString(tmp, 64);

		if (strcmp(tmp, PASSWORD) != 0) {

			// do nothing: this service cannot be stopped !!!
			return;
		}

		// continue processing: allow stop command;
		// just erase the password from the shared string
		// before proceding
		m_strShared.setString("");
	}

	// otherwise, use standard handler function
	CService::HandleMsg(dwOpcode);
}

// Process user control requests
bool CMyService::OnUserControl(DWORD dwOpcode)
{
	long tmp;

    switch (dwOpcode) {
    case MYCONTROLCODE_SAVE_TIME_LEFT:

        // Save the current status in the IPC class
		m_strShared.setNum(m_cCountDown.GetSecondsLeft());
        return TRUE;

    case MYCONTROLCODE_EXTEND_TIME:

        // try to extend remained time
		tmp = m_strShared.getNum();
		m_cCountDown.ExtendEndTime(tmp);
        return TRUE;

    default:
        break;
    }
    return FALSE; // say not handled
}

void CMyService::PrintUsage()
{
	printf(
		"\n\n" NAME " usage\n-----------------------\n\n"
		"\t\t" EXE_NAME " [password] command [command arguments]\t\nwhere\n"
		"\tpassword\tis the password required to use the commands below\n"
		
		"\tcommand\t\tis one of:\n\t\t\t-install\tto install the service\n"
		"\t\t\t-unistall\tto unistall the service\n"
		"\t\t\t-stop\t\tto stop the service\n"
		"\t\t\t-add xxx\tto add 'xxx' minutes to the countdown\n"

		"\n\t\t\tor one of (these do not require the password):\n"
		"\t\t\t-help\t\tto recall these info\n"
		"\t\t\t-version\tto get info about the service\n"
		"\t\t\t-start\t\tto start the service\n"
		"\t\t\t-query\t\tto query the remaining seconds\n"
		"\n\n");
}

bool CMyService::ParseStandardArgs(int argc, char* argv[])
{
	bool b = FALSE;

	// check argument count
	if (argc == 1) {
		
		// VERY VERY IMPORTANT: IF THE SERVICE IS CALLED WITHOUT
		// ANY ARGUMENT (ARGC == 1), IT MUST CALL THE STARTSERVICE
		// FUNCTION; OTHERWISE WIN32 WON'T BE ABLE TO START IT !!!!
		//
		// Note also that the StartService() function will work
		// ONLY if the caller is Win32, that is, if this instance
		// of the service is the system instance.
		// If the user tries from the MS-DOS prompt to run the
		// service program (THIS program) without any argument,
		// the StartService() function won't work, but the program
		// will print the usage instructions (which are harmless
		// if the caller is Windows).
		StartService();

		// in case the caller is not Windows but the user from
		// an MS-DOS prompt...
		PrintUsage();
		return TRUE;
	}

	// the commands which do no require the password...
	b |= (_stricmp(argv[1], "-start") == 0);
	b |= (_stricmp(argv[1], "-help") == 0);
	b |= (_stricmp(argv[1], "-version") == 0);
	b |= (_stricmp(argv[1], "-query") == 0);
	if (argc == 2 && b) {
		
		// th START command doesn't required the password: bypass the check
		return CService::ParseStandardArgs(argc, argv);
	}

	// check the password first of all
	if (strcmp(argv[1], PASSWORD) != 0) {
		printf("Sorry, invalid password.\n");
		return TRUE;
	}

	// ok, password matched:
	// delete the password argument
	char *old = argv[1];
	for (int i=1; i < argc-1; i++)
		argv[i] = argv[i+1];
	argv[i] = old;
	argc--;

	return CService::ParseStandardArgs(argc, argv);
}

bool CMyService::OnUserOption(int count, char **arg)
{
	if (_stricmp(arg[1], "-start") == 0) {


		// We must START the service. We sure cannot use the StartService()
		// function: this is not the system instance of the service; this
		// is an instance created by the user from the MS-DOS prompt...
		// we must use Win32 service-access functions...

		if (StartServiceFromDOS())
			printf("Service started.\n");
		else {
			
			if (!IsInstalled())
				printf("Couldn't start the service (it's not installed).\n");
			else
				printf("Couldn't start the service. Error %d.\n", GetLastError());
		}

	} else if (_stricmp(arg[1], "-stop") == 0) {

		if (!IsRunningFromDOS()) {
			printf("Service is already stopped.\n");
			return TRUE;
		}

		// use the virtual function defined in CMyService: it
		// doesn't just query the service to stop: it first
		// sets in the shared string the password !!!
		StopServiceFromDOS();

		if (IsRunningFromDOS())
			printf("Couldn't stop the service.\n");
		else
			printf("Service stopped.\n");

	} else if (_stricmp(arg[1], "-add") == 0) {

		if (count < 3) {
			printf("Please retype the command specifying the amount of "
				"time to add (in min).\n");
			return TRUE;
		}

		if (!IsRunningFromDOS()) {
			printf("Couldn't add time: the service is stopped.\n");
			return TRUE;
		}

		// build a client string
		ShareString min;
		if (!min.Create(IO_MAP))
			printf("Couldn't set the number of minutes to add (Error %d).", GetLastError());

		// set in the string the number of seconds to add
		int n = atol(arg[2])*60;
		min.setNum(n);

		// ask the service to save its status in the shared string
		if (!SendUserCommandFromDOS(MYCONTROLCODE_EXTEND_TIME)) {
			printf("Couldn't send to the service the add command.\n");
			return TRUE;
		}

		printf("Added %d seconds (that is, %d minutes).\n", n, n/60);

	} else if (_stricmp(arg[1], "-query") == 0) {


		// we can query the service only if it is running
		if (!IsRunningFromDOS()) {
			printf("Service is stopped; it must be running to query it.\n");
			return TRUE;
		}

		// build a client string
		ShareString seconds;
		if (!seconds.Create(IO_MAP))
			printf("Couldn't read the number of seconds remaining (Error %d).", GetLastError());

		// ask the service to save its status in the shared string
		if (!SendUserCommandFromDOS(MYCONTROLCODE_SAVE_TIME_LEFT)) {
			printf("Couldn't send to the service the query command.\n");
			return TRUE;
		}

		// now, we must retrieve from the shared string the
		// number of seconds left
		long n = seconds.getNum();
		printf("%d seconds left.\n", (int)n);

	} else {

		// some wrong argument was specified...
		PrintUsage();
	}

	return TRUE;
}

bool CMyService::StopServiceFromDOS()
{
	// build a client string
	ShareString pwd;
	if (!pwd.Create(IO_MAP))
		return FALSE;

	// set the password inside the string
	pwd.setString(PASSWORD);

	// ask the service to stop
	return CService::StopServiceFromDOS();
}

