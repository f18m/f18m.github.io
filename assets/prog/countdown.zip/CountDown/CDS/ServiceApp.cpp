///////////////////////////////////////////////////////////////////////
// ServiceApp.cpp
// 
// Implements the main() function, which is called when user 
// try to access the service from the command line.
//
///////////////////////////////////////////////////////////////////////



// includes
#include "ServiceApp.h"
#include "MyService.h"



//////////////////////////////////////////////
// USAGE INSTRUCTIONS:
//
// 1) To install, build this program, then from the command line run it
//    with the right password and the '-i' option
// 2) To unistall it, run it with the '-u' option and AFTER it, open
//    MMC->Services and choose Stop for this service...



int main(int argc, char* argv[])
{
    // Create the service object
    CMyService MyService;
    
    // Parse for standard arguments (install, uninstall, version etc.)
    MyService.ParseStandardArgs(argc, argv);

    // When we get here, the service has been stopped
    return MyService.m_Status.dwWin32ExitCode;
}




