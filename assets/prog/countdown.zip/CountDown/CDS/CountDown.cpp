///////////////////////////////////////////////////////////////////////
// CountDown.cpp
// 
// Implementation of the CCountDown class.
// CCountDown has the following tasks:
// 
// 1) time-check: when the Run() function is called, it checks
//                if the time has expired and eventually calls
//                the TurnOffPC() function
//
// 2) PC turn-off: CCountDown::TurnOffPC() function works in two
//                 fases: first it logoffs the current user and
//                 then, after seconds, it power-off the PC.
// 
///////////////////////////////////////////////////////////////////////


// this class needs WinNT/2000/XP defines....
#define _WIN32_WINNT			0x0501

// includes
#include <windows.h>
#include <winuser.h>
#include <Reason.h>

#include "Service.h"		// for the DebugMsg function
#include "CountDown.h"



// the data used by async message box
MSG_DATA g_msgData;

// g_msgData will point to these arrays
char str[256], str2[64];



void CCountDown::Run()
{
	int i;

	// CHECK FOR TURNOFF-STEPS
	// do NOT use GetTurnOffTime() !!
	if (((long)GetTickCount()) >= (long)(m_nTurnOffTime)) {
		
		// end time coincides with the current time: turn off the PC
		TurnOffPC();
	}
	

	// CHECK FOR ADVICES
	for (i=0; i < NUM_WARNINGS; i++) {

		// check if we must trig one advice...
		if (((int)GetTickCount()) >= (GetTurnOffTime() - m_nWarning[i]*1000) &&
			m_bWarning[i] == FALSE) {
			
			// set this warning as already shown
			m_bWarning[i] = TRUE;

			int sec = m_nWarning[i], 
				min = sec/60, n = sec-min*60;
			if (sec > 60) {

				// add the minutes 
				wsprintf(str2, "%d minute%s", 
						min, ((min > 1) ? "s" : ""));
				if (n > 0) {

					// and, eventually, the seconds
					wsprintf(str2, "%s and %d seconds", str2, n);
				}
			} else {

				// add just the seconds
				wsprintf(str2, "%d seconds", sec);
			}

			wsprintf(str, "WARNING: time left before poweroff is %s", str2);
			wsprintf(str2, "WARNING %d/%d", i+1, NUM_WARNINGS);

			// show a warning to the user
			ShowAsyncMsg(str, str2);			
		}
	}
}

void CCountDown::ResetWarnings()
{
	// no warnings already marked....
	for (int c=0; c < NUM_WARNINGS; c++)
		m_bWarning[c] = FALSE;
}

long CCountDown::GetSecondsLeft()
{
	// be sure not to return a negative number....
	int n = (int)(GetTurnOffTime()-GetTickCount())/1000;
	return ((n > 0) ? n : 0);
}

long CCountDown::GetTurnOffTime()
{
	// don't count the time between the first and the second
	// turn off step...
	return m_nEndTime;
}

void CCountDown::SetCountLenght(unsigned long nSeconds)
{
	// set end time
	m_nEndTime = GetTickCount() + nSeconds*1000;
	m_nTurnOffTime = m_nEndTime + m_nInterTurnOffStepTime*1000;
	ResetWarnings();
}

void CCountDown::ExtendEndTime(unsigned long ext)
{
	DebugMsg("CCountDown::ExtendEndTime - extending end time by %d millisecs", ext);

	// extend end time
	m_nEndTime += ext*1000;
	m_nTurnOffTime = m_nEndTime + m_nInterTurnOffStepTime*1000;

	// reset warnings
	ResetWarnings();
}




// static

long CCountDown::SystemTime2Seconds(SYSTEMTIME &time)
{
	// convert hour & minutes in seconds
	return time.wHour*3600+time.wMinute*60+time.wSecond;
}

void CCountDown::TurnOffPC()
{
	HANDLE h;
	
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &h)) {
		DebugMsg("Cannot open the access token for this thread...");
		return;
	}
	
	if (!SetPrivilege(h, SE_SHUTDOWN_NAME, TRUE)) {
		DebugMsg("Cannot set shutdown privileges for this access token...");
		return;
	}

	// turn off the PC in two steps
//	if (n == 0) {
	
	// try to turn off PC
	// in a first instance, in this step I tried to logoff and then
	// to poweroff in the second step but I couldn't manage to get
	// the EWX_LOGOFF flag to work.....
	DebugMsg("CCountDown::TurnOffPC - I'm going to power-off......");
	ExitWindowsEx(EWX_POWEROFF | EWX_FORCEIFHUNG, SHTDN_REASON_MAJOR_HARDWARE |
		SHTDN_REASON_MINOR_MAINTENANCE | SHTDN_REASON_FLAG_PLANNED);

	m_nTurnOffTime += m_nInterTurnOffStepTime*1000;
	/*	} else if (n == 1) {
		
		// then, power-off the PC
		DebugMsg("CCountDown::TurnOffPC - I'm going to power-off again !!!");
		ExitWindowsEx(EWX_POWEROFF | EWX_FORCEIFHUNG, SHTDN_REASON_MAJOR_HARDWARE |
				SHTDN_REASON_MINOR_MAINTENANCE | SHTDN_REASON_FLAG_PLANNED);
	}*/

	// ExitWindowsEx seems not to work if we close the handle...
	// why ? boooooooooooooooooooooooooohhhhhhhhhhhhh.... :-)
	//CloseHandle(h);
}

bool CCountDown::SetPrivilege(
				  HANDLE hToken,          // access token handle
				  LPCTSTR lpszPrivilege,  // name of privilege to enable/disable
				  BOOL bEnablePrivilege   // to enable or disable privilege
				  ) 
{
	TOKEN_PRIVILEGES tp;
	LUID luid;
	
	if ( !LookupPrivilegeValue( 
        NULL,            // lookup privilege on local system
        lpszPrivilege,   // privilege to lookup 
        &luid ) ) {      // receives LUID of privilege
		DebugMsg("LookupPrivilegeValue error: %u\n", GetLastError() ); 
		return FALSE; 
	}
	
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;
	
	// Enable the privilege or disable all privileges.
	
	AdjustTokenPrivileges(
		hToken, 
		FALSE, 
		&tp, 
		sizeof(TOKEN_PRIVILEGES), 
		(PTOKEN_PRIVILEGES) NULL, 
		(PDWORD) NULL); 
	
	// Call GetLastError to determine whether the function succeeded.
	
	if (GetLastError() != ERROR_SUCCESS) { 
		DebugMsg("AdjustTokenPrivileges failed: %u\n", GetLastError() ); 
		return FALSE; 
	} 
	
	return TRUE;
}
 



// asynchronously message box implementation

void CCountDown::ShowAsyncMsg(char *msg, char *title)
{	
	g_msgData.pContent = msg;
	g_msgData.pTitle = title;

	CreateThread(NULL, 0, CCountDown::AsyncMsgProc, (void *)(&g_msgData), 0, NULL);
}

unsigned long CCountDown::AsyncMsgProc(void *lpParameter)
{
	MSG_DATA *p = (MSG_DATA *)lpParameter;

	// show the message box
	MessageBox(NULL, p->pContent, p->pTitle, 
		MB_OK | MB_SYSTEMMODAL | MB_SERVICE_NOTIFICATION | MB_ICONEXCLAMATION);

	// this exit code won't be read by anything
	return -1;
}











