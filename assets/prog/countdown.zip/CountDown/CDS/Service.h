///////////////////////////////////////////////////////////////////////
// Service.h
// 
// Defines the class CService, the parent of CMyService.
// CService is a skeleton class taken from the NTService example
// of the MSDN library.
//
///////////////////////////////////////////////////////////////////////



#ifndef _SERVICE_H_
#define _SERVICE_H_


void DebugMsg(const char* pszFormat, ...);


// Implements a basic NT/2000/XP service
class CService
{
public:									// functions

	// constructor & destructor
    CService(const char *szServiceName, 
		DWORD dwStartType = SERVICE_DEMAND_START,
		DWORD dwServiceType = SERVICE_WIN32_OWN_PROCESS);
    virtual ~CService();

	// non-overrideables
    bool IsInstalled();
    bool Install();
    bool Uninstall();
	bool IsRunning();
    bool StartService();
    bool Initialize();
    void SetStatus(DWORD dwState);

protected:

	// overrideables
    virtual bool ParseStandardArgs(int argc, char* argv[]);
	virtual void HandleMsg(int);

	// service-access functions: you must use these functions
	// if the current instance of the program is not the
	// system instance of the service.... (overrideables)
	virtual bool StartServiceFromDOS();
	virtual bool StopServiceFromDOS();
	virtual bool IsRunningFromDOS();
	virtual bool SendUserCommandFromDOS(int cmd);

	// which should be overridden
    virtual void Run();
	virtual bool OnInit();
    virtual void OnStop();
    virtual void OnInterrogate();
    virtual void OnPause();
    virtual void OnContinue();
    virtual void OnShutdown();
    virtual bool OnUserControl(DWORD dwOpcode);
	virtual bool OnUserOption(int count, char **arg);

	// which MUST be overridden
	virtual const char *GetDisplayName() = 0;
	virtual const char *GetDescription() = 0;
    
    // static member functions
    static void WINAPI ServiceMain(DWORD dwArgc, LPTSTR* lpszArgv);
    static void WINAPI Handler(DWORD dwOpcode);


public:								// variables
    SERVICE_STATUS m_Status;

protected:

	// this value is used by CService::Install() but must be specified in
	// the constructor
	DWORD m_dwStartType;

	// same for m_dwStartType
	DWORD m_dwServiceType;

	// info shown with the "-version" command
    int m_iMajorVersion;
    int m_iMinorVersion;


private:

    SERVICE_STATUS_HANDLE m_hServiceStatus;

	// use IsRunning() to retrieve the value of this variable
    bool m_bIsRunning;

    // static data
    static CService* m_pThis; // nasty hack to get object ptr

    // data members
    char m_szServiceName[32];
};


#endif // _SERVICE_H_

