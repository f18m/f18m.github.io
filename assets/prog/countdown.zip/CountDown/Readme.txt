CountDown general info
----------------------

This folder contains two programs: the CountDown service (.\CDS; it's the Win32 service which turnoffs the computer if the countdown reaches zero secs) and the CountDown service controller (.\CDS Ctrl; it's the MFC dialog-based application which lets the user to interact with the service countdown).

The service before turning off the PC shows the user two warnings (one at 5-min before and one at 1-min left); besides, it has a complete control system available from DOS: just type 'CDS -help' at the prompt. The CDS service uses the class ShareString to communicate with the other processes: that class was originally developed by John Bell; thanks to him.

The service controller lets you to see the time that is remaining with a beautiful digital clock I took from www.codeproject.com (thanks to the original author, Nikolai Serdiuk). It also allows you to add time to the countdown and so, to postpone the countdown.

NOTE: the project is not aimed to be secure but if the users of your workstation do not know what the word 'debugger' means, the extra simple password-check I implemented both in the service and in the service controller should be enough.



CountDown installation
----------------------

NOTE: before using this two programs, you should change the passwords in the files:
- CDS\MyService.h
- CDS Ctrl\Count Down Service ControlDlg.h

To install the CountDown service, you must compile it, copy it in a secure place (I suggest you something like C:\windows\system32) and then:

	cds [your password] -install
	cds [your password] -start

Now, you can run the CountDown service controller and wait for the fatal moment.....



CountDown tecniques
-------------------

CountDown service & controller contain a bunch of different useful tricks, algorithms and classes:
1) how to create a complete Win32 service (CDS\Service.h)
2) how to communicate with a service from other applications and, in general, how to perform IPC (interprocess communication) (MemoryMap.h & .cpp)
3) how to start/stop/query a win32 service (CDS\Service.h)
4) how to show a message box asynchronously (CDS\CountDown.cpp)
5) how to turn off the computer (CDS\CountDown.cpp)


I hope the program will be useful to you.

The author,
Francesco Montorsi
fr_m@hotmail.com
