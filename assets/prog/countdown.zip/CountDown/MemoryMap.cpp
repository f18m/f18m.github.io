///////////////////////////////////////////////////////////////////////
// MemoryMap.cpp
// 
// Implementation of the ShareString class. 
// This is a modified version of the ShareString class created by
// FallenHobit (John Bell) which was downloaded from planetsourcecode.com.
//
///////////////////////////////////////////////////////////////////////



// includes
#include <windows.h>
#include "MemoryMap.h"





#ifdef USE_SECURITY_ATTRIBUTES

#include <Sddl.h>

// CreateMyDACL.
//    Create a security descriptor that contains the DACL you want.
//    This function uses SDDL to make Deny and Allow ACEs.
//
// Parameter:
//    SECURITY_ATTRIBUTES * pSA
//    Pointer to a SECURITY_ATTRIBUTES structure. It is the caller's
//    responsibility to properly initialize the structure and to free 
//    the structure's lpSecurityDescriptor member when the caller has
//    finished using it. To free the structure's lpSecurityDescriptor 
//    member, call the LocalFree function.
// 
// Return value:
//    FALSE if the address to the structure is NULL. 
//    Otherwise, this function returns the value from the
//    ConvertStringSecurityDescriptorToSecurityDescriptor function.
BOOL CreateMyDACL(SECURITY_ATTRIBUTES * pSA)
{
     // Define the SDDL for the DACL. This example sets 
     // the following access:
     //     Built-in guests are denied all access.
     //     Anonymous logon is denied all access.
     //     Authenticated users are allowed read/write/execute access.
     //     Administrators are allowed full control.
     // Modify these values as needed to generate the proper
     // DACL for your application. 
     TCHAR * szSD = TEXT("D:")       // Discretionary ACL
        TEXT("(D;OICI;GA;;;BG)")     // Deny access to built-in guests
        TEXT("(D;OICI;GA;;;AN)")     // Deny access to anonymous logon
        TEXT("(A;OICI;GRGWGX;;;AU)") // Allow read/write/execute to authenticated users
        TEXT("(A;OICI;GA;;;BA)");    // Allow full control to administrators

    if (NULL == pSA)
        return FALSE;

     return ConvertStringSecurityDescriptorToSecurityDescriptor(
                szSD,
                SDDL_REVISION_1,
                &(pSA->lpSecurityDescriptor),
                NULL);
}

#endif




// constructor function....
ShareString::ShareString()
{
	m_pMapStart=0;
	m_hFile=m_hMap=NULL;
	m_szFileName[0]='\0';
}

ShareString::ShareString(const char *mapname, bool srv, const char *filename, bool bHide)
{
	m_pMapStart=0;
	m_hFile=m_hMap=NULL;
	m_szFileName[0]='\0';
	Create(mapname, srv, filename, bHide);
}

// destructor ...closes any open handles
ShareString::~ShareString()
{
	Delete();
}

bool ShareString::Create(const char *mapname, bool srv, const char *filename, bool bHide)
{
	if (mapname == NULL)
		return FALSE;

	// check to make sure the name is less than 36 chars long and 
	// that we are the server side of the file mapping
	if ((srv) && (strlen(mapname) < 36)) {

		unsigned long gt;
		char test[10];
		LPSECURITY_ATTRIBUTES psa;

		// copy the file name (it will be eventually used by destructor)
		strcpy(m_szFileName, filename);
		strcpy(test, "created");
		int tstln = strlen(test);
		
#ifdef USE_SECURITY_ATTRIBUTES

		// fill out the Security structure needed by CreateFile()
		SECURITY_ATTRIBUTES sa;
		sa.nLength = sizeof(SECURITY_ATTRIBUTES);
		sa.bInheritHandle = FALSE;  
		
		// Call function to set the DACL. The DACL is set in the SECURITY_ATTRIBUTES 
		// lpSecurityDescriptor member.
		if (!CreateMyDACL(&sa))
			return FALSE;
		psa = &sa;

#else
		// use default security atrtibutes: works with all Win32 versions
		psa = NULL;
#endif
		
		// create the file
		int attr = FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS;
		if (bHide) attr |= FILE_ATTRIBUTE_HIDDEN;
		m_hFile = CreateFile(m_szFileName, GENERIC_READ | GENERIC_WRITE, 0, 
												psa, CREATE_ALWAYS, attr, 0);
		if (m_hFile == INVALID_HANDLE_VALUE)			
			return FALSE;
		
		// write an initial record to intialize the file
		WriteFile(m_hFile, test, tstln*sizeof(char), &gt, 0);
		FlushFileBuffers(m_hFile);
		
		// get a mapping handle to it
		m_hMap = CreateFileMapping(m_hFile, psa, PAGE_READWRITE, 0, 0, mapname);
		if (m_hMap == NULL)
			return FALSE;
		
		// map the file into memory
		m_pMapStart = (DWORD *)MapViewOfFile(m_hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);

	} else if (!srv) {

		// ok..we are not the server side...so try to dind 
		// the file in memory and set up for io 
		if (!MapFile(mapname))
			return FALSE;
	}
	
	// we can be sure to have a working map of the file...
	return TRUE;
}

void ShareString::Delete()
{
	if (m_pMapStart)
		UnmapViewOfFile(m_pMapStart);
	if (m_hMap)
		CloseHandle(m_hMap);
    if (m_hFile && m_hFile != INVALID_HANDLE_VALUE) {

		// we are the server-side
		// close the file & delete it
		CloseHandle(m_hFile);
		DeleteFile(m_szFileName);
	}
}

// helper function...does the actual data transference to or from the shared memory block
void ShareString::CopyData(void *dest, void *source, DWORD size)
{
	memmove(dest, source, size);
}

// returns true or false for the memory block handle....
bool ShareString::isFileMapped()
{
	return (bool)(m_pMapStart != 0);
}

// added 4/11 to attempt to remap a file on the reader's side....this way you can poll for
// the files creation, then read from it once it exists....I do this in Locutus.........
bool ShareString::MapFile(const char *name)
{
	if (!isFileMapped()) {

		// try to open the file mapping
		m_hMap = OpenFileMapping(FILE_MAP_WRITE, FALSE, name);
		if (m_hMap == NULL)
			return FALSE;
	
		// map our view of it
		m_pMapStart = (DWORD *)MapViewOfFile(m_hMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);		
	}

	return TRUE;
}

// copys a string into the shared memory block
void ShareString::setString(const char *str)
{
	if (m_pMapStart)
	{
		int n = strlen(str);
		
		// sets a flag char for the other side to know 
		// where the end of the string is located
		char *pnewbuf = new char[n+1];
		strcpy(pnewbuf, str);
		pnewbuf[n] = '`';
		n++;
		
		int size = n*sizeof(char);
		CopyData((void *)m_pMapStart, (void *)pnewbuf, size);
		delete [] pnewbuf;
	}
}

// copys a string out of the shared memory block
void ShareString::getString(char *str, int length)
{
	if (m_pMapStart)
	{
		// copy the data 
		CopyData((void *)str, (void *)m_pMapStart, length);
		int l = findchar(str, '`');			// find the flag char
		
		// if we found the flag char...
		if (l > 0)
		{
			// ...strip off the data left of this char position, otherwise...
			left(str, l);
		}
		else 
		{
			// ... set the result buffer as empty
			str[0] = '\0';
		}
	}
}


// private function for finding the position
// of a character in a string..
int ShareString::findchar(const char *s, const char fnd)
{
	int len = strlen(s);
	int ret=-1;
	bool cont = true;
	for (int i = 0; i < len; i++)
	{
		if ((s[i] == fnd) && (cont == true))
		{
			ret = i;
			cont = false;
		}
	}
	return ret;
}

// private function for getting the left
// part of a string.....................
void ShareString::left(char *s, int num)
{
	int i = strlen(s);
	int c = 0;
	char *hld = new char[num + 1];
	if (i > num || i == num)
	{
		for (c = 0; c < num; c++)
		{
			hld[c] = s[c];
		}
		hld[num] = '\0';
		for (c = 0; c < (num + 1); c++)
		{
			s[c] = hld[c];
		}
	}
	delete[] hld;
}

long ShareString::getNum()
{
	char str[32];
	
	getString(str, 32);
	return atol(str);
}

void ShareString::setNum(long n)
{
	char str[32];
	ltoa(n, str, 10);

	setString(str);
}



