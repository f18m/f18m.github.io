///////////////////////////////////////////////////////////////////////
// Globals.h
// 
// Contains some definitions useful both to the service (.\CDS)
// and to service control application (.\CDS Ctrl)
//
///////////////////////////////////////////////////////////////////////


#ifndef GLOBALS_H


// the name of our service
#define SERVICE_NAME						"CountDown"

// the name of the mapped file used to exchange data between
// the service and the other apps
#define IO_MAP								"CDS"

// the service messages base IDs
#define SERVICE_CONTROL_USER				128

// the command IDs specific for CountDown service
#define MYCONTROLCODE_SAVE_TIME_LEFT		SERVICE_CONTROL_USER + 0
#define MYCONTROLCODE_EXTEND_TIME			SERVICE_CONTROL_USER + 1


#endif