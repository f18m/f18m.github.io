#if !defined(AFX_DIGITALCLOCK_H__1E750CCC_7E13_4943_924E_993ECD703C65__INCLUDED_)
#define AFX_DIGITALCLOCK_H__1E750CCC_7E13_4943_924E_993ECD703C65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Clock.h : header file
//
#include "Digit.h"
#include "Colon.h"
/////////////////////////////////////////////////////////////////////////////
// CDigitalClock window

class CDigitalClock
{
// Construction
public:
	CDigitalClock();

// Attributes
public:

// Implementation
public:
	virtual ~CDigitalClock();

	// Generated message map functions
protected:


public:
	long GetYOffset();
	long GetXOffset();
	COLORREF GetBackgroundColor();
	long GetSegmentWidth();
	long GetSegmentOffset();
	COLORREF GetInactiveColour();
	COLORREF GetActiveColour();
	void SetActiveColour(COLORREF crlActive);

	void SetInactiveColour(COLORREF clrInactive);

	void SetSegmentWidth( const long lWidth );
	void SetYOffset( const long lYOffset );
	void SetXOffset( const long lXOffset );
	void SetSegmentOffset( const long lOffset );
	void Calculate( const RECT & rc );	
	void SetBackgroundColor( COLORREF bkgndColor );	
	long GetClockTime();
	
	void Draw( HDC dc, const RECT & rc );
	
	
	// added by Francesco Montorsi to implement
	// the Countdown feature
	unsigned long m_nSeconds;
	bool m_bCountDown;
	bool m_bDrawHours;


protected:

	void SetColour();

protected:

	struct Clock
	{
		CDigit hourCL[2];
		CDigit minCL[2];
		CDigit secondCL[2];
		CColon colon[2];
	};

	long m_lOFF;
	long m_lXOFF;
	long m_lYOFF;
	long m_lWidth;

	Clock m_strClock;

	HBRUSH m_bgndBrush;
	bool m_colonState;

	COLORREF m_colorBkgnd;
	COLORREF m_colorActive;
	COLORREF m_colorInactive;

	tm m_tmTime;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIGITALCLOCK_H__1E750CCC_7E13_4943_924E_993ECD703C65__INCLUDED_)
