// Count Down Service ControlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Count Down Service Control.h"
#include "Count Down Service ControlDlg.h"

// for the service communication
#include <windows.h>
#include <winsvc.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CCountDownServiceControlDlg dialog

CCountDownServiceControlDlg::CCountDownServiceControlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCountDownServiceControlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCountDownServiceControlDlg)
	m_strPwd = _T("");
	m_nTime = 30;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hSmallIcon = AfxGetApp()->LoadIcon(IDR_SMALLFRAME);
}

void CCountDownServiceControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCountDownServiceControlDlg)
	DDX_Text(pDX, IDC_PASSWORD, m_strPwd);
	DDX_Text(pDX, IDC_TIME, m_nTime);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCountDownServiceControlDlg, CDialog)
	//{{AFX_MSG_MAP(CCountDownServiceControlDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_ADDTIME, OnAddtime)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCountDownServiceControlDlg message handlers

BOOL CCountDownServiceControlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "Sync" menu item to system menu.

	// IDM_SYNC must be in the system command range.
	ASSERT((IDM_SYNC & 0xFFF0) == IDM_SYNC);
	ASSERT(IDM_SYNC < 0xF000);
	ASSERT((IDM_ALWAYSONTOP & 0xFFF0) == IDM_ALWAYSONTOP);
	ASSERT(IDM_ALWAYSONTOP < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		
		// add the Synchronize & Keep always on top commands
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_SYNC, "Synchronize");
		pSysMenu->AppendMenu(MF_STRING, IDM_ALWAYSONTOP, "Keep always on top");
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hSmallIcon, FALSE);		// Set small icon
	
	
	// get the rect where we must place our digital clock
	GetDlgItem(IDC_CLOCK)->GetWindowRect(&m_rcClock);
	GetDlgItem(IDC_CLOCK)->ShowWindow(SW_HIDE);
	ScreenToClient(&m_rcClock);
	m_cClock.Calculate(m_rcClock);

	// change clock properties
	m_cClock.SetInactiveColour(RGB(5, 60, 7));
	m_cClock.m_bCountDown = TRUE;
	SyncClock();

	// create the timer of our countdown
	SetTimer(1, 1000, NULL);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCountDownServiceControlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_SYNC) {

		SyncClock();

	} else if ((nID & 0xFFF0) == IDM_ALWAYSONTOP) {

		int n = GetExStyle();

		// add or remove the TOPMOST style
		if (n & WS_EX_TOPMOST) {

			GetSystemMenu(FALSE)->CheckMenuItem(IDM_ALWAYSONTOP, MF_UNCHECKED);
			SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		} else {

			GetSystemMenu(FALSE)->CheckMenuItem(IDM_ALWAYSONTOP, MF_CHECKED);
			SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		}

	} else {

		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCountDownServiceControlDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hSmallIcon);
	}
	else
	{
		// draw the digital clock
		m_cClock.Draw(GetDC()->m_hDC, m_rcClock);

		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCountDownServiceControlDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hSmallIcon;
}

void CCountDownServiceControlDlg::OnTimer(UINT nIDEvent) 
{
	// decrement the seconds remaining
	m_nNow--;
	SetClock();

	m_cClock.Draw(GetDC()->m_hDC, m_rcClock);	
	CDialog::OnTimer(nIDEvent);
}

long CCountDownServiceControlDlg::GetSecondsLeft() 
{
	// build a client string
	ShareString seconds;
	if (!seconds.Create(IO_MAP)) {
		ErrorBox("Couldn't create the shared string.");
		return 0;
	}

	// ask the service to copy in the string the seconds remaining
	if (!SendUserCommandFromDOS(MYCONTROLCODE_SAVE_TIME_LEFT)) {
		ErrorBox("Couldn't connect to the service.");
		return 0;
	}

	return seconds.getNum();
}


void CCountDownServiceControlDlg::OnAddtime() 
{
	// first of all, check if the inserted password is okay
	if (!UpdateData(TRUE))
		return;

	if (m_strPwd != PASSWORD) {
		ErrorBox("Sorry, invalid password.");
		return;
	}

	// build a client string
	ShareString toadd;
	if (!toadd.Create(IO_MAP)) {
		ErrorBox("Couldn't create the shared string.");
		return;		
	}

	// check that we are not subtracting too much time !!!
	// (m_nTime can be negative)
	if ((GetSecondsLeft()+m_nTime*60) < 0) {

		// user cannot subtract so much time to go under 2 minutes
		m_nTime = (120-GetSecondsLeft())/60;
	}

	// and set in the string the num of seconds to add
	CString str;
	str.Format("%d", m_nTime*60);
	toadd.setString(str);

	// then, send to the service the request
	if (!SendUserCommandFromDOS(MYCONTROLCODE_EXTEND_TIME)) {
		ErrorBox("Couldn't connect to the service.");
		return;
	}

	// reset the counter
	SyncClock();

	// reset the password field
	m_strPwd = "";
	UpdateData(FALSE);
}

bool CCountDownServiceControlDlg::SendUserCommandFromDOS(int cmd)
{
    // open the service control manager
    SC_HANDLE hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (hSCM == NULL) {
		return FALSE;
	}

    // open the service
    SC_HANDLE hService = OpenService(hSCM,
                                     SERVICE_NAME,
                                     SERVICE_USER_DEFINED_CONTROL);
	if (hService == NULL) {
		return FALSE;
	}

    // stop the service
    SERVICE_STATUS ss;
    BOOL b = ControlService(hService,
                            cmd,		// the user-defined command
                            &ss);
	if (!b) {
		return FALSE;
	}

    // close the service handle
    CloseServiceHandle(hService);

    // close the service control manager handle
    CloseServiceHandle(hSCM);

	return TRUE;
}

void CCountDownServiceControlDlg::ErrorBox(const CString &str)
{
	MessageBox(str, "Error", MB_ICONERROR | MB_OK);
}

void CCountDownServiceControlDlg::SyncClock()
{
	// set the clock seconds appropriately
	m_nNow = GetSecondsLeft();
	SetClock();
}

void CCountDownServiceControlDlg::SetClock()
{
	int h = m_nNow/3600;

	// check if we must show/hide the hours in the clock...
	if (h > 0) {
		
		m_cClock.m_bDrawHours = TRUE;
		m_cClock.m_nSeconds = ((m_nNow > UPPER_LIMIT) ? UPPER_LIMIT : m_nNow);		
		m_cClock.Calculate(m_rcClock);

	} else {

		m_cClock.m_bDrawHours = FALSE;
		m_cClock.m_nSeconds = m_nNow;
		m_cClock.m_nSeconds = ((m_nNow < LOWER_LIMIT) ? LOWER_LIMIT : m_nNow);
		m_cClock.Calculate(m_rcClock);
	}
}