//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Count Down Service Control.rc
//
#define IDM_SYNC                        0x0010
#define IDM_ALWAYSONTOP                 0x0020
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COUNTDOWNSERVICECONTROL_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDR_SMALLFRAME                  131
#define IDC_CLOCK                       1000
#define IDC_PASSWORD                    1001
#define IDC_TIME                        1002
#define IDC_ADDTIME                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
