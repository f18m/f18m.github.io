// DigitalClock.cpp : implementation file
//

#include "stdafx.h"
#include "Clock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDigitalClock
//-----------------------------------------------------------------------------
CDigitalClock::CDigitalClock()
{	
	// default values
	m_lOFF = 8;
	m_lXOFF = 4;
	m_lYOFF = 4;
	m_lWidth = 2;

	m_colonState = true;
	m_bCountDown = false;
	m_bDrawHours = false;
	m_nSeconds = 0;

	SetBackgroundColor( RGB(0,0,0) );
	SetActiveColour( RGB( 19, 240, 24 ) );
	SetInactiveColour( RGB( 5, 90, 7 ) );
}
//-----------------------------------------------------------------------------
CDigitalClock::~CDigitalClock()
{
	
}
//-----------------------------------------------------------------------------

/////////////////////////////////////////////////////////////////////////////
// CDigitalClock message handlers
//-----------------------------------------------------------------------------
void CDigitalClock::Calculate( const RECT & rc )
{
	int a, b, c;
	RECT rcDigits;
	memcpy( &rcDigits, &rc, sizeof(RECT) );

	InflateRect( &rcDigits, -m_lXOFF, -m_lYOFF );	
	
	if (m_bDrawHours)
		a = 9, b = 6, c = 3;
	else
		a = 6, b = 4, c = 1;
	
	
	//�������� ������ ���� ����������� � �������� ����� ����
	const int nDW = (((rcDigits.right - rcDigits.left) - a*m_lOFF)/b);

	RECT rcDG[6];
	memset( &rcDG, 0, sizeof(RECT)*6 );
	
	if (m_bDrawHours) {
		rcDG[0].left = rcDigits.left;
		rcDG[0].right = rcDigits.left + nDW;
		rcDG[0].top = rcDigits.top;
		rcDG[0].bottom = rcDigits.bottom;
		
		rcDG[1].left = rcDigits.left + nDW + m_lOFF;
		rcDG[1].right = rcDG[1].left + nDW;
		rcDG[1].top = rcDigits.top;
		rcDG[1].bottom = rcDigits.bottom;

	} else {

		rcDG[0].left = rcDigits.left;
		rcDG[0].right = rcDigits.left;
		rcDG[0].top = rcDigits.top;
		rcDG[0].bottom = rcDigits.bottom;
		
		rcDG[1].left = rcDigits.left;
		rcDG[1].right = rcDG[1].left;
		rcDG[1].top = rcDigits.top;
		rcDG[1].bottom = rcDigits.bottom;
	}
	
	rcDG[2].left = rcDG[1].right + c*m_lOFF;
	rcDG[2].right = rcDG[2].left + nDW;
	rcDG[2].top = rcDigits.top;
	rcDG[2].bottom = rcDigits.bottom;

	rcDG[3].left = rcDG[2].right + m_lOFF;
	rcDG[3].right = rcDG[3].left + nDW;
	rcDG[3].top = rcDigits.top;
	rcDG[3].bottom = rcDigits.bottom;

	rcDG[4].left = rcDG[3].right + 3*m_lOFF;
	rcDG[4].right = rcDG[4].left + nDW;
	rcDG[4].top = rcDigits.top;
	rcDG[4].bottom = rcDigits.bottom;

	rcDG[5].left = rcDG[4].right + m_lOFF;
	rcDG[5].right = rcDG[5].left + nDW;
	rcDG[5].top = rcDigits.top;
	rcDG[5].bottom = rcDigits.bottom;

	RECT rcCL[2];
	memset( &rcCL, 0, sizeof(RECT)*2 );

	rcCL[0].left = rcDG[1].right + m_lOFF;
	rcCL[0].right = rcCL[0].left + m_lOFF;
	rcCL[0].top = rcDigits.top;
	rcCL[0].bottom = rcDigits.bottom;

	rcCL[1].left = rcDG[3].right + m_lOFF;
	rcCL[1].right = rcCL[1].left + m_lOFF;
	rcCL[1].top = rcDigits.top;
	rcCL[1].bottom = rcDigits.bottom;
	
	if (m_bDrawHours) {
		m_strClock.hourCL[0].setParameters( rcDG[0], m_lWidth );
		m_strClock.hourCL[1].setParameters( rcDG[1], m_lWidth );
	}
	m_strClock.minCL[0].setParameters( rcDG[2], m_lWidth );
	m_strClock.minCL[1].setParameters( rcDG[3], m_lWidth );
	m_strClock.secondCL[0].setParameters( rcDG[4], m_lWidth );
	m_strClock.secondCL[1].setParameters( rcDG[5], m_lWidth );
	
	if (m_bDrawHours) {
		m_strClock.colon[0].setParameters( rcCL[0], m_lWidth );
	}
	m_strClock.colon[1].setParameters( rcCL[1], m_lWidth );
}
//-----------------------------------------------------------------------------
void CDigitalClock::Draw( HDC dc, const RECT & rc )
{
	::FillRect( dc, &rc, m_bgndBrush );
	
	if (m_bCountDown) {

		m_tmTime.tm_hour = m_nSeconds/3600; 
		m_tmTime.tm_min = m_nSeconds/60-m_tmTime.tm_hour*60;
		m_tmTime.tm_sec = m_nSeconds-m_tmTime.tm_min*60-m_tmTime.tm_hour*3600;

	} else {

		const time_t currTime = time( NULL );
		const tm * currTm = localtime( &currTime );
		memcpy( &m_tmTime, currTm, sizeof(tm) );
	}
	
	if (m_bDrawHours) {
		m_strClock.hourCL[0].drawDigit( dc, (m_tmTime.tm_hour / 10) );
		m_strClock.hourCL[1].drawDigit( dc, (m_tmTime.tm_hour % 10) );
	}
	m_strClock.minCL[0].drawDigit( dc, (m_tmTime.tm_min / 10) );
	m_strClock.minCL[1].drawDigit( dc, (m_tmTime.tm_min % 10) );	

	m_strClock.secondCL[0].drawDigit( dc, (m_tmTime.tm_sec / 10) );
	m_strClock.secondCL[1].drawDigit( dc, (m_tmTime.tm_sec % 10) );

#ifdef BLINK_COLON
	m_colonState = !m_colonState;
#else
	// DO NOT BLINK THE COLON: I don't like it... :-)
#endif
	
	if (m_bDrawHours) {
		m_strClock.colon[0].drawColon( dc, m_colonState ); 		
	}
	m_strClock.colon[1].drawColon( dc, m_colonState ); 
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetBackgroundColor( COLORREF bkgndColor )
{
	m_colorBkgnd = bkgndColor;
	m_bgndBrush = ::CreateSolidBrush( bkgndColor );	
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetColour()
{	
	m_strClock.hourCL[0].setDigitColor( m_colorActive, m_colorInactive );
	m_strClock.hourCL[1].setDigitColor( m_colorActive, m_colorInactive );
	m_strClock.minCL[0].setDigitColor( m_colorActive, m_colorInactive );
	m_strClock.minCL[1].setDigitColor( m_colorActive, m_colorInactive );
	m_strClock.secondCL[0].setDigitColor( m_colorActive, m_colorInactive );
	m_strClock.secondCL[1].setDigitColor( m_colorActive, m_colorInactive );

	m_strClock.hourCL[0].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.hourCL[1].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.minCL[0].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.minCL[1].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.secondCL[0].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.secondCL[1].setLineColor( m_colorActive, m_colorInactive );

	m_strClock.colon[0].setColonColor( m_colorActive, m_colorInactive );
	m_strClock.colon[0].setLineColor( m_colorActive, m_colorInactive );
	m_strClock.colon[1].setColonColor( m_colorActive, m_colorInactive );
	m_strClock.colon[1].setLineColor( m_colorActive, m_colorInactive );	
}
//-----------------------------------------------------------------------------
//
long CDigitalClock::GetClockTime()
{
	return mktime( &m_tmTime );
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetSegmentOffset( const long lOffset)
{
	m_lOFF = lOffset;
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetXOffset(const long lXOffset)
{
	m_lXOFF = lXOffset;
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetYOffset(const long lYOffset)
{
	m_lYOFF = lYOffset;
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetSegmentWidth(const long lWidth)
{
	m_lWidth = lWidth;
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetActiveColour(COLORREF crlActive)
{
 	m_colorActive = crlActive;
 	
 	SetColour();
}
//-----------------------------------------------------------------------------
void CDigitalClock::SetInactiveColour(COLORREF clrInactive)
{
	m_colorInactive = clrInactive;
 
 	SetColour();
}

//-----------------------------------------------------------------------------
COLORREF CDigitalClock::GetActiveColour()
{
	return m_colorActive;
}
//-----------------------------------------------------------------------------
COLORREF CDigitalClock::GetInactiveColour()
{
	return m_colorInactive;
}
//-----------------------------------------------------------------------------
long CDigitalClock::GetSegmentOffset()
{
	return m_lOFF;
}
//-----------------------------------------------------------------------------
long CDigitalClock::GetSegmentWidth()
{
	return m_lWidth;
}
//-----------------------------------------------------------------------------
COLORREF CDigitalClock::GetBackgroundColor()
{
	return m_colorBkgnd;
}
//-----------------------------------------------------------------------------
long CDigitalClock::GetXOffset()
{
	return m_lXOFF;
}
//-----------------------------------------------------------------------------
long CDigitalClock::GetYOffset()
{
	return m_lYOFF;
}
//-----------------------------------------------------------------------------