// Count Down Service Control.h : main header file for the COUNT DOWN SERVICE CONTROL application
//

#if !defined(AFX_COUNTDOWNSERVICECONTROL_H__C5642076_4BE5_405A_AFE5_8F474D49D8DB__INCLUDED_)
#define AFX_COUNTDOWNSERVICECONTROL_H__C5642076_4BE5_405A_AFE5_8F474D49D8DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCountDownServiceControlApp:
// See Count Down Service Control.cpp for the implementation of this class
//

class CCountDownServiceControlApp : public CWinApp
{
public:
	CCountDownServiceControlApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCountDownServiceControlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCountDownServiceControlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COUNTDOWNSERVICECONTROL_H__C5642076_4BE5_405A_AFE5_8F474D49D8DB__INCLUDED_)
