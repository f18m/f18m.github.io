// Count Down Service ControlDlg.h : header file
//

#if !defined(AFX_COUNTDOWNSERVICECONTROLDLG_H__F516FD2F_EA1A_494A_B451_7D8E0BB21392__INCLUDED_)
#define AFX_COUNTDOWNSERVICECONTROLDLG_H__F516FD2F_EA1A_494A_B451_7D8E0BB21392__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "Clock.h"
#include "../MemoryMap.h"
#include "../Globals.h"


#define PASSWORD			"pigreco"

// when remaining time exceeds 99h:59m:59s, the clock hangs on that moment
#define UPPER_LIMIT			60*60*99+60*59+59

// when the system begins to turn off, hang on zero
#define LOWER_LIMIT			0


/////////////////////////////////////////////////////////////////////////////
// CCountDownServiceControlDlg dialog

class CCountDownServiceControlDlg : public CDialog
{
// Construction
public:
	CCountDownServiceControlDlg(CWnd* pParent = NULL);	// standard constructor

	CDigitalClock m_cClock;
	CRect m_rcClock;

	long GetSecondsLeft();
	bool SendUserCommandFromDOS(int cmd);
	void ErrorBox(const CString &);
	void SyncClock();
	void SetClock();

	long m_nNow;


// Dialog Data
	//{{AFX_DATA(CCountDownServiceControlDlg)
	enum { IDD = IDD_COUNTDOWNSERVICECONTROL_DIALOG };
	CString	m_strPwd;
	long	m_nTime;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCountDownServiceControlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon, m_hSmallIcon;

	// Generated message map functions
	//{{AFX_MSG(CCountDownServiceControlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnAddtime();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COUNTDOWNSERVICECONTROLDLG_H__F516FD2F_EA1A_494A_B451_7D8E0BB21392__INCLUDED_)
